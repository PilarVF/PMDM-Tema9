package com.example.proyectomultimedia3

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.animation.Animation
import android.view.animation.AnimationUtils
import android.widget.ImageView

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Encuentra el ImageView1 en el layout:
        val imageView1 = findViewById<ImageView>(R.id.imageView1)

        // Cargar la animación desde un archivo XML:
        val animation1: Animation = AnimationUtils.loadAnimation(this, R.anim.scale)

        // Aplicar la animación al ImageView1:
        imageView1.startAnimation(animation1)

        // Encuentra el ImageView2 en el layout:
        val imageView2 = findViewById<ImageView>(R.id.imageView2)

        // Cargar la animación desde un archivo XML:
        val animation2: Animation = AnimationUtils.loadAnimation(this, R.anim.slide_in)

        // Aplicar la animación al ImageView2:
        imageView2.startAnimation(animation2)

        // Encuentra el ImageView3 en el layout:
        val imageView3 = findViewById<ImageView>(R.id.imageView3)

        // Cargar la animación desde un archivo XML:
        val animation3: Animation = AnimationUtils.loadAnimation(this, R.anim.rotation)

        // Aplicar la animación al ImageView3:
        imageView3.startAnimation(animation3)

        // Encuentra el ImageView4 en el layout:
        val imageView4 = findViewById<ImageView>(R.id.imageView4)

        // Cargar la animación desde un archivo XML:
        val animation4: Animation = AnimationUtils.loadAnimation(this, R.anim.transparency)

        // Aplicar la animación al ImageView4:
        imageView4.startAnimation(animation4)
    }
}